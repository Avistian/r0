# Generator coverage

Status: PASS. Selection: none.
Downstream usefulness: NOT_MEASURED. Counts describe this bounded run only.

| Cell | Proposed | Generated | Valid | Selected | Selected share |
| --- | ---: | ---: | ---: | ---: | --- |
| gp/added/binary | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| gp/added/multiclass | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| gp/added/regression | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| gp/none/binary | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| gp/none/multiclass | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| gp/none/regression | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| interaction/added/binary | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| interaction/added/multiclass | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| interaction/added/regression | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| interaction/none/binary | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| interaction/none/multiclass | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| interaction/none/regression | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| linear/added/binary | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| linear/added/multiclass | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| linear/added/regression | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| linear/none/binary | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| linear/none/multiclass | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| linear/none/regression | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| mlp/added/binary | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| mlp/added/multiclass | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| mlp/added/regression | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| mlp/none/binary | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| mlp/none/multiclass | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| mlp/none/regression | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| scm/added/binary | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| scm/added/multiclass | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| scm/added/regression | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| scm/none/binary | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| scm/none/multiclass | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| scm/none/regression | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| tree/added/binary | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| tree/added/multiclass | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| tree/added/regression | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| tree/none/binary | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| tree/none/multiclass | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |
| tree/none/regression | 2 | 2 | 2 | 2 | 2/72 (0.027777777777777776) |

## Findings

- warning: REPEATED_MECHANISM: 36 repeated mechanism groups; not automatic invalidity

Shares have explicit stage denominators in report.json; null means a zero denominator.
Missingness processes, subgroup and shift coverage remain catalog-only, not measured.
