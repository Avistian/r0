# Generator coverage

Status: PASS. Selection: drop_added_noise.
Downstream usefulness: NOT_MEASURED. Counts describe this bounded run only.

| Cell | Proposed | Generated | Valid | Selected | Selected share |
| --- | ---: | ---: | ---: | ---: | --- |
| gp/added/binary | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| gp/added/multiclass | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| gp/added/regression | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| gp/none/binary | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| gp/none/multiclass | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| gp/none/regression | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| interaction/added/binary | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| interaction/added/multiclass | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| interaction/added/regression | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| interaction/none/binary | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| interaction/none/multiclass | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| interaction/none/regression | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| linear/added/binary | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| linear/added/multiclass | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| linear/added/regression | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| linear/none/binary | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| linear/none/multiclass | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| linear/none/regression | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| mlp/added/binary | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| mlp/added/multiclass | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| mlp/added/regression | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| mlp/none/binary | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| mlp/none/multiclass | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| mlp/none/regression | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| scm/added/binary | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| scm/added/multiclass | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| scm/added/regression | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| scm/none/binary | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| scm/none/multiclass | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| scm/none/regression | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| tree/added/binary | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| tree/added/multiclass | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| tree/added/regression | 2 | 2 | 2 | 0 | 0/36 (0.0) |
| tree/none/binary | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| tree/none/multiclass | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |
| tree/none/regression | 2 | 2 | 2 | 2 | 2/36 (0.05555555555555555) |

## Findings

- warning: SELECTION_REMOVED_CELL: gp/added/binary
- warning: SELECTION_REMOVED_CELL: gp/added/multiclass
- warning: SELECTION_REMOVED_CELL: gp/added/regression
- warning: SELECTION_REMOVED_CELL: interaction/added/binary
- warning: SELECTION_REMOVED_CELL: interaction/added/multiclass
- warning: SELECTION_REMOVED_CELL: interaction/added/regression
- warning: SELECTION_REMOVED_CELL: linear/added/binary
- warning: SELECTION_REMOVED_CELL: linear/added/multiclass
- warning: SELECTION_REMOVED_CELL: linear/added/regression
- warning: SELECTION_REMOVED_CELL: mlp/added/binary
- warning: SELECTION_REMOVED_CELL: mlp/added/multiclass
- warning: SELECTION_REMOVED_CELL: mlp/added/regression
- warning: SELECTION_REMOVED_CELL: scm/added/binary
- warning: SELECTION_REMOVED_CELL: scm/added/multiclass
- warning: SELECTION_REMOVED_CELL: scm/added/regression
- warning: SELECTION_REMOVED_CELL: tree/added/binary
- warning: SELECTION_REMOVED_CELL: tree/added/multiclass
- warning: SELECTION_REMOVED_CELL: tree/added/regression
- warning: REPEATED_MECHANISM: 36 repeated mechanism groups; not automatic invalidity

Shares have explicit stage denominators in report.json; null means a zero denominator.
Missingness processes, subgroup and shift coverage remain catalog-only, not measured.
