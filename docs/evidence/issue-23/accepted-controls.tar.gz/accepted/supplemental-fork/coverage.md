# Generator coverage

Status: PASS. Selection: none.
Downstream usefulness: NOT_MEASURED. Counts describe this bounded run only.

| Cell | Proposed | Generated | Valid | Selected | Selected share |
| --- | ---: | ---: | ---: | ---: | --- |
| scm/added/regression | 1 | 1 | 1 | 1 | 1/2 (0.5) |
| scm/none/regression | 1 | 1 | 1 | 1 | 1/2 (0.5) |

## Findings

- warning: REPEATED_MECHANISM: 1 repeated mechanism groups; not automatic invalidity

Shares have explicit stage denominators in report.json; null means a zero denominator.
Missingness processes, subgroup and shift coverage remain catalog-only, not measured.
