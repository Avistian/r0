# Generator coverage

Status: FAIL. Selection: none.
Downstream usefulness: NOT_MEASURED. Counts describe this bounded run only.

| Cell | Proposed | Generated | Valid | Selected | Selected share |
| --- | ---: | ---: | ---: | ---: | --- |
| linear/added/regression | 1 | 0 | 0 | 0 | 0/0 (None) |
| linear/none/regression | 1 | 0 | 0 | 0 | 0/0 (None) |

## Findings

- error: GENERATION_FAILED: ValueError: deliberate generation failure for b15bdd997befa619d9cb27dcc0ca894997034e567dd8664add915f51ab9801d5
- error: GENERATION_FAILED: ValueError: deliberate generation failure for 2b663c4ab37dba56e90021fed8373b4e08714684f087bdc8e97e65c15d350a84

Shares have explicit stage denominators in report.json; null means a zero denominator.
Missingness processes, subgroup and shift coverage remain catalog-only, not measured.
