#!/usr/bin/env bash
set -u
cd /tmp/r0-28-functions-spec-690297b
export PYTHONPATH=/tmp/r0-28-functions-spec-690297b/source/src
/home/avist/Projects/r0/.venv/bin/python -B reproduce.py > reproduction.log 2>&1
status=$?
printf '%s\n' "$status" > reproduction.exit
cat reproduction.log
exit "$status"
