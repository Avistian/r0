"""Minimal independent reproduction of the first-distance-tie defect."""

import hashlib
import json
import platform
import sys
from dataclasses import asdict
from pathlib import Path

import torch

import r0
from r0.modules import priors

ROOT = Path(__file__).resolve().parent
assert Path(r0.__file__).resolve().is_relative_to(ROOT / "source")
torch.set_num_threads(1)
record = priors.FrozenDiscretizationFunction(
    centers=((15.0, 0.0), (13.0, 2.0)),
    linear=priors.FrozenLinearFunction(((1.0, 0.0),)),
    p=1.0,
)
inputs = torch.tensor([[0.0, 0.0]], dtype=torch.float64)
# Independent exact integer arithmetic: |15| + |0| = |13| + |2| = 15.
distances = [abs(15) + abs(0), abs(13) + abs(2)]
assert distances == [15, 15]
expected = 15.0
observed = priors.evaluate_frozen_function(record, inputs).item()
source_distances = torch.cdist(inputs, torch.tensor(record.centers, dtype=torch.float64), p=1)
assert source_distances.tolist() == [[15.0, 15.0]]
imports = {}
for name, module in sorted(sys.modules.items()):
    path = getattr(module, "__file__", None)
    if name == "r0" or name.startswith("r0."):
        assert path is not None
        resolved = Path(path).resolve()
        assert resolved.is_relative_to(ROOT / "source")
        imports[name] = {
            "path": str(resolved),
            "sha256": hashlib.sha256(resolved.read_bytes()).hexdigest(),
        }
receipt = {
    "verdict": "REJECT" if observed != expected else "DEFECT_NOT_REPRODUCED",
    "python": sys.version,
    "executable": sys.executable,
    "platform": platform.platform(),
    "torch": torch.__version__,
    "threads": torch.get_num_threads(),
    "device": "cpu",
    "dtype": "float64",
    "fixture": asdict(record),
    "inputs": inputs.tolist(),
    "expected": expected,
    "observed": observed,
    "exact_integer_distances": distances,
    "cached_source_expression_distances": source_distances.tolist(),
    "program_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "imports": imports,
}
(ROOT / "reproduction.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({k: v for k, v in receipt.items() if k != "imports"}, indent=2))
if observed != expected:
    raise AssertionError(f"first nearest center required {expected}, observed {observed}")
