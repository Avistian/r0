"""Retain complete immutable review input/evidence hashes."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
files = {}
for path in sorted(ROOT.rglob("*")):
    if path.is_file() and path.name != "manifest.json":
        files[str(path.relative_to(ROOT))] = {
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "bytes": path.stat().st_size,
        }
for name, receipt in (
    ("check_ties.py", "first-failure.json"),
    ("reproduce.py", "reproduction.json"),
):
    assert files[name]["sha256"] == json.loads((ROOT / receipt).read_text())["program_sha256"]
manifest = {
    "source": "690297b3b0508f9d57af2e78ae190f94f263ad70",
    "base": "cb7977a916ff6f11d95790b2de4dd591ab8d3f39",
    "verdict": "REJECT",
    "initial_cases": {"passed": 12, "failed": 1, "not_run": 85},
    "minimal_reproductions": 1,
    "harness_failures": 0,
    "files": files,
}
(ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(f"Manifest retained {len(files)} file identities; executed program hashes match.")
