# Frozen function specification review: REJECT

SOURCE 690297b3b0508f9d57af2e78ae190f94f263ad70
BASE cb7977a916ff6f11d95790b2de4dd591ab8d3f39
Owned worktree /tmp/r0-28, unchanged HEAD, only untracked .venv.

Finding: src/r0/modules/priors/lib/frozen_function_evaluation.py:89-101
normalizes each distance separately, then compares rounded mantissa/exponent
pairs. For p=1, X=(0,0), ordered centers (15,0),(13,2), and linear map [1,0],
both exact distances equal 15. The first nearest-center contract requires 15,
but evaluation returns 13. The source cdist expression also gives [15,15].
The independent primary oracle is exact integer arithmetic, not implementation.
Research specification docs/research/0028-joint-root-function-plans.md:109 says
"select first minimum"; docs/issue-28-frozen-functions.md:27 repeats the contract.
The small finite exact-integer example is a center-selection semantic error,
not a demand for bit identity across source arithmetic adaptations.

## Reproduction

Run `bash /tmp/r0-28-functions-spec-690297b/reproduce.sh`.
Expected exit 1, expected 15, observed 13, retained in reproduction.log/.json/.exit.
Python 3.12.3, Torch 2.15.0+cpu, float64 CPU, one Torch thread. Existing environment
/home/avist/Projects/r0/.venv. No installs, downloads, cloud, or author tests used.
reproduction.json records every imported r0 module path/hash under the exported
source. manifest.json hashes all retained evidence and exported source/base files.

Initial sweep command:
```
PYTHONPATH=/tmp/r0-28-functions-spec-690297b/source/src /home/avist/Projects/r0/.venv/bin/python -B /tmp/r0-28-functions-spec-690297b/check_ties.py > /tmp/r0-28-functions-spec-690297b/check_ties.log 2>&1
```
It checked integer L1 ties for totals 3 through 15: 12 passed, the 13th failed.
It stopped immediately; totals 16..100 were NOT_RUN. The minimal two-center
reproduction is one additional execution of the same defect. No harness mistakes
occurred. Final formatted program bytes match executed SHA-256 receipts.

## Reconstruction from git

Original export commands (full archive, not a new worktree), from /tmp/r0-28:
```
mkdir /tmp/r0-28-functions-spec-690297b
mkdir /tmp/r0-28-functions-spec-690297b/source /tmp/r0-28-functions-spec-690297b/base
git archive 690297b3b0508f9d57af2e78ae190f94f263ad70 | tar -x -C /tmp/r0-28-functions-spec-690297b/source
git archive cb7977a916ff6f11d95790b2de4dd591ab8d3f39 | tar -x -C /tmp/r0-28-functions-spec-690297b/base
cp /tmp/r0-28-source-read/I2func.py /tmp/r0-28-functions-spec-690297b/I2func.py
git diff cb7977a916ff6f11d95790b2de4dd591ab8d3f39...690297b3b0508f9d57af2e78ae190f94f263ad70
```
Use an empty destination to reconstruct; preserve this rejected evidence.
I2func.py local SHA-256 ff2939197b353f6d11a3fbaf0e27586998bdf93527dad11f24698ff296ce2f6c.
Attributed to TabICL 9530bd65a7b806f6ad4f9f4335af745577e9d3cc;
NOT freshly upstream verified. Cached source expression is corroboration only.

## Coverage and limitations

Static reading covered all eight records, evaluators, decoder, resource accounting,
source cached equations, MLP stages/flags/widths, and cheap child restrictions.
Executable review stopped at the first real defect as instructed. Remaining seven
family numerical oracles, JSON corruption, resource boundaries, MLP combinations,
chunk/repeat/immutability and broader extreme-value cases are NOT_RUN in this
independent review. No component acceptance. CPU/GPU agreement, browser, Colab,
scale, fitting and sampling provenance remain unverified. No full issue #28 claim.
The component correctly documents sampling/fitting/graph integration as missing;
research lines 134-137 and accepted spec lines 14-18,76-80,122-130 still require it.
No scope creep identified in the bounded component. Author owns remaining
implementation; independent verifier owns unexecuted checks after repair.
