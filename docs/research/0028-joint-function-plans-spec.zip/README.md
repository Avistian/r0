# Portable function-plan component evidence

Verdict: **PASS_COMPONENT** at SOURCE
`a6ab8c70902d9d474cea12e7cab2aadf67ca35f5`, against BASE
`731f6a44b309a75fc5c5f756168550eac48b372a`.

This directory is self-contained for reviewer inputs. Its `original/` directory
is an exact copy of the complete original artifact set, including its unchanged
19-entry manifest and initial harness failures. `original-preservation.json`
records byte-for-byte verification against the original directory. No original
artifact was rewritten. The top-level manifest separately inventories original
and portable files.

## Reproduce in another checkout

Use an existing compatible environment with the repository dependencies. No
installation, download, or network access is performed by these commands. The
checkout must contain the pinned SOURCE git object and matching source bytes.
Run from that checkout's repository root. Put the whole portable bundle anywhere
outside the checkout; set the three paths below for the local environment.

```sh
export R0_REVIEW_BUNDLE=/absolute/path/to/portable-bundle
export UV_PROJECT_ENVIRONMENT=/absolute/path/to/existing/venv
export UV_CACHE_DIR=/absolute/path/to/existing/uv-cache
# Optional when scripts and recovered archive inputs are in separate locations:
export R0_REVIEW_INPUTS=/absolute/path/to/recovered/inputs
R0_REVIEW_RUN=$(mktemp -d)
R0_REVIEW_OUTPUT="$R0_REVIEW_RUN/main" timeout 60s python3 scripts/run_check.py python "$R0_REVIEW_BUNDLE/probe.py" > "$R0_REVIEW_RUN/main.log" 2>&1
R0_REVIEW_OUTPUT="$R0_REVIEW_RUN/ownership" timeout 60s python3 scripts/run_check.py python "$R0_REVIEW_BUNDLE/ownership_legacy.py" > "$R0_REVIEW_RUN/ownership.log" 2>&1
```

`R0_REVIEW_INPUTS` defaults to the bundle's `inputs/` directory; setting it allows
plain-text verifier scripts to use separately recovered evidence-archive inputs.
Both its supplied environment value and resolved location are retained.

The scripts require a fresh output directory and refuse to overwrite an earlier
execution. `verification.py` checks that imported `priors` is exactly the current
checkout's `src/r0/modules/priors/__init__.py`. It checks every tracked priors file,
the reviewed requirements/design/standards documents, the two changed tests, and
the check runner against `git show SOURCE:path`. HEAD is observed only, never used
to select reference bytes. The original BASE source needed for numerical
compatibility is bundled and hash-checked, so the BASE git object is unnecessary.

Each run records import location, Python executable/version, source-file hashes,
cached-input hashes, program/helper hashes, argv, environment, working directory,
observed HEAD and status. Tests use only the public priors seam; source comparison
and cached law attribution are separate from numerical realization evidence.

## Final retained execution

- `logs/probe-release.log`: 706 assertions across 96 plans, **PASS_COMPONENT**.
- `logs/ownership-release.log`: 444 exact BASE scalar comparisons, 16 ownership
  mutations and five matrix-family round trips, **PASS_COMPONENT**.
- `results/release-main/`: final import/source identity and all-family fixtures.
- `results/release-ownership/`: final identity, ownership fixtures and BASE input.
- `logs/ruff-release.log`: final programs/helper Ruff-clean; each below 20,000 bytes.
- `execution.json`: exact commands and environment used for these final bytes.

Earlier portable outputs and logs remain retained: initial runs preceded a lint-only
line-length fix; `final-*` runs preceded the requested inputs-directory override;
`publish-*` runs exercised that override before its environment value was added
to execution metadata. `attempt_helpers/` retains exact helper bytes for each
attempt, verified against the identities printed by those executions. Final
release bytes were executed in fresh `results/release-*` directories. Original
harness failures remain described in `original/REVIEW.md`; none is a product defect.

## Retained cached inputs and attribution

`inputs/I2func.py` and `inputs/_base.py` are byte-for-byte retained local cache
copies, historically attributed by the reviewed design to TabICL commit
`9530bd65a7b806f6ad4f9f4335af745577e9d3cc`:

- `src/tabicl/prior/graph_lib/_function.py`
- `src/tabicl/prior/graph_lib/_base.py`

No fresh upstream verification was performed. `inputs/provenance.json` records
the original cache locations, precise SHA256 hashes, and attribution status.
`inputs/base_parameter_preferences.txt` is retained r0 source at BASE, originally
read through `git show BASE:src/r0/modules/priors/lib/parameter_preferences.py`.

This remains the narrow named-sampling/typed-plan/strict-JSON/ledger-binding
component verdict. Realization, fitting, raw provenance, roots, graph integration,
whole issue #28, GPU/browser/Colab/scale/scientific acceptance remain unestablished.
