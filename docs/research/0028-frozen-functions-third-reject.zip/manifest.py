"""Freeze artifact identities and verify final executed program bytes."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
files = {}
for path in sorted(ROOT.rglob("*")):
    if path.is_file() and path.name != "manifest.json":
        files[str(path.relative_to(ROOT))] = {
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "bytes": path.stat().st_size,
        }
receipt = json.loads((ROOT / "reproduce_quasi_tie-receipt.json").read_text())
for name, digest in receipt["programs"].items():
    assert files[name]["sha256"] == digest
for name, digest in {
    "check_ties.py": "de12a47a0798fd584c6be409dc6187d45aa69b3100f49f255d94225f948182e9",
    "check_roundtrip.py": "45c473b0feb1f305f8b69c9488e27b63bf2c296c692a1cdd4246e2067ef192dc",
}.items():
    assert files[name]["sha256"] == digest
for path in ROOT.glob("*.py"):
    assert path.stat().st_size <= 20000
manifest = {
    "source": "ed5b67a406619f174335dece2ff382f0a6bf753e",
    "base": "cb7977a916ff6f11d95790b2de4dd591ab8d3f39",
    "verdict": "REJECT",
    "original_ties_passed": 98,
    "original_roundtrip_passed": 1,
    "final_equation_cases_passed": 131,
    "final_equation_cases_failed": 1,
    "minimal_reproductions": 2,
    "numerical_harness_failures": 1,
    "files": files,
}
(ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(f"Retained {len(files)} files; program hashes match final executed bytes.")
