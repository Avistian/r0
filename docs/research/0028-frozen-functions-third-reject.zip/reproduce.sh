#!/usr/bin/env bash
set -u
cd /tmp/r0-28-functions-spec-ed5b67a
export PYTHONPATH=/tmp/r0-28-functions-spec-ed5b67a/source/src
/home/avist/Projects/r0/.venv/bin/python -B reproduce_quasi_tie.py
