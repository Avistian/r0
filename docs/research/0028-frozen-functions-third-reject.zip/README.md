# Frozen function independent specification review: REJECT

SOURCE ed5b67a406619f174335dece2ff382f0a6bf753e
BASE cb7977a916ff6f11d95790b2de4dd591ab8d3f39
Read-only preflight /tmp/r0-28: pinned HEAD, untracked .venv and two author-owned
rejection packaging artifacts. No tests or source modified by reviewer. Prior
690297b and c58706e rejection directories remain unchanged.

## First real defect

At p=.5, X=(0,0), ordered centers ((64,0),(9,25)), and output linear [1,0], both
exact quasi-distances equal64: (sqrt64+sqrt0)^2=(sqrt9+sqrt25)^2=64.
The required first center outputs64, but implementation outputs9.
Independent perfect-square integer radicals establish the oracle; cached-source
`torch.cdist(..., p=.5)` corroborates distances [64,64]. The power-of-two scaling
plus floating power/root still changes a true tie into an inequality across
multidimensional centers, despite the special one-axis repair.

Spec docs/research/0028-joint-root-function-plans.md:109 requires "select first
minimum"; docs/issue-28-frozen-functions.md:27 repeats it. Finding is in
src/r0/modules/priors/lib/frozen_function_evaluation.py:94-110.
This is a branch-choice error on small exact integers, not a bit-identity demand.

Run `bash /tmp/r0-28-functions-spec-ed5b67a/reproduce.sh`; expected exit1.
quasi-tie.json/log/exit retain the minimal result. The receipt
reproduce_quasi_tie-receipt.json retains environment and every imported r0
module path/hash. The named program retains the independent integer derivation.

## Verified coverage and counts

Unchanged check_ties.py: all98 original integer L1 tie cases pass.
Unchanged check_roundtrip.py: prior MLP arithmetic and JSON reconstruction pass.
Final check_equations.py: 132 cases reached, 131 passed and one failed;
execution stopped at the first real product defect. Each passing case includes
independent scalar/NumPy/Decimal expected arithmetic, JSON roundtrip, separate
single-row evaluation, repeated-call equality, returned-tensor mutation, input
and frozen-record preservation, and Torch global RNG preservation.

Before rejection, the final sweep covered all eight families; all25 allowed cheap
product pairings; all12 MLP depth/start/end combinations; three row-local channel
activations; six authored activation parameters; quadratic input widths1/20/21,
selected-order and nonsymmetric matrices; source tree count/depth bounds1/1 and
128/7; four extreme tree-mean cases including cancellation; discretization p
boundaries, sole centers, sparse1D/3D adjacent floats from minsubnormal to1e308,
opposite-sign subtraction overflow; EM p/q boundaries, scalar normalization,
component counts2/16/34 and extreme sigma. Scalar oracles preserve output-by-input
orientation, tree split bits, RFF phase arithmetic, EM scalar normalization, and
MLP stage order. The additional exact p=.5 tie sweep failed at a=3,b=5.

One initial numerical harness failure was retained in harness-history/: Decimal
precision100 was insufficient for exact cancellation of ~1e308 inputs, producing
a false expected residual. Corrected to1100 and restarted the final sweep.
That false REJECT is a verifier mistake, not a product defect. Two preliminary
PT018 lint findings were fixed before execution and retained. A first minimal
reproduction's generic finish logger printed PASS as a count label despite its
REJECT event and exit1; its log/program are retained, and final reproduction
suppresses that misleading summary. Two minimal reproduction executions confirmed
the same product defect. Do not add repeated attempts to unique coverage counts.

JSON corruption/adversarial shape/version/recursion, invalid child-family tests,
exact/one-below aggregate resource admission, broader MLP dimension bounds, and
full cached legacy transform execution remain NOT_RUN after the stop. Cached
cdist expression corroboration is not a full legacy sweep. No component pass.
Source sampling, fitting ancestry/provenance and graph integration remain open;
no scientific, GPU, browser, Colab, scale or full issue28 acceptance.

## Environment and commands

Existing /home/avist/Projects/r0/.venv/bin/python, Python3.12.3, NumPy/Torch versions
in receipt, Torch2.15.0+cpu, float64 CPU, one thread. No installs, cloud, downloads,
secrets, author test execution or worktree mutations.

For each program check_ties.py, check_roundtrip.py, check_equations.py,
reproduce_quasi_tie.py:
```
PYTHONPATH=/tmp/r0-28-functions-spec-ed5b67a/source/src /home/avist/Projects/r0/.venv/bin/python -B /tmp/r0-28-functions-spec-ed5b67a/PROGRAM.py
```
Logs identify completed runs; check_equations and reproduce_quasi_tie exit1.
Every verifier program is below20KB. Final Ruff format/check use source/pyproject.toml
and known-first-party r0. Manifest verifies executed program hashes against the
minimal reproduction receipt and unchanged historical reproducers.

## Exact archive reconstruction

From /tmp/r0-28 into an empty artifact directory:
```
mkdir /tmp/r0-28-functions-spec-ed5b67a
mkdir /tmp/r0-28-functions-spec-ed5b67a/source /tmp/r0-28-functions-spec-ed5b67a/base
git archive ed5b67a406619f174335dece2ff382f0a6bf753e src pyproject.toml AGENTS.md CODING_STANDARDS.md docs/requirements.md docs/specs/0028-causal-network-generators.md docs/research/0028-joint-root-function-plans.md docs/issue-28-frozen-functions.md | tar -x -C /tmp/r0-28-functions-spec-ed5b67a/source
git archive cb7977a916ff6f11d95790b2de4dd591ab8d3f39 src pyproject.toml AGENTS.md CODING_STANDARDS.md docs/requirements.md docs/specs/0028-causal-network-generators.md docs/research/0028-joint-root-function-plans.md | tar -x -C /tmp/r0-28-functions-spec-ed5b67a/base
cp /tmp/r0-28-functions-spec-690297b/check_ties.py /tmp/r0-28-functions-spec-ed5b67a/check_ties.py
cp /tmp/r0-28-functions-spec-c58706e/check_roundtrip.py /tmp/r0-28-functions-spec-ed5b67a/check_roundtrip.py
cp /tmp/r0-28-functions-spec-690297b/I2func.py /tmp/r0-28-functions-spec-ed5b67a/I2func.py
git diff cb7977a916ff6f11d95790b2de4dd591ab8d3f39...ed5b67a406619f174335dece2ff382f0a6bf753e
```
I2func.py SHA256 ff2939197b353f6d11a3fbaf0e27586998bdf93527dad11f24698ff296ce2f6c,
attributed TabICL9530bd65a7b806f6ad4f9f4335af745577e9d3cc, not freshly upstream verified.
