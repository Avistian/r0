"""Retain exact artifacts, source bindings and final executed program identities."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
files = {}
for path in sorted(ROOT.rglob("*")):
    if path.is_file() and path.name != "manifest.json":
        files[str(path.relative_to(ROOT))] = {
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "bytes": path.stat().st_size,
        }
assert (
    files["check_roundtrip.py"]["sha256"]
    == json.loads((ROOT / "roundtrip.json").read_text())["program_sha256"]
)
assert files["check_ties.py"]["sha256"] == (
    "de12a47a0798fd584c6be409dc6187d45aa69b3100f49f255d94225f948182e9"
)
manifest = {
    "source": "c58706ec044568cc6b449a428c32d93c9b5ca7a1",
    "base": "cb7977a916ff6f11d95790b2de4dd591ab8d3f39",
    "verdict": "REJECT",
    "tie_cases_passed": 98,
    "mlp_arithmetic_checks_passed": 1,
    "roundtrip_cases_failed": 1,
    "harness_failures": 0,
    "files": files,
}
(ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(f"Retained {len(files)} file identities; final executed bytes match.")
