# Repaired frozen function specification review: REJECT

SOURCE c58706ec044568cc6b449a428c32d93c9b5ca7a1
BASE cb7977a916ff6f11d95790b2de4dd591ab8d3f39
Read-only preflight: /tmp/r0-28 at the pinned HEAD, only untracked .venv.
Later author edits to tests and new rejection artifacts appeared; they were
excluded because all verification imports use the pinned git export. Reviewer
made no worktree/source/test edits.
Original /tmp/r0-28-functions-spec-690297b rejection archive was not modified.

## Repair check and new failure

The original check_ties.py was copied byte-for-byte; SHA256 is
`de12a47a0798fd584c6be409dc6187d45aa69b3100f49f255d94225f948182e9`.
It now passes all 98 integer L1 tie cases (totals 3 through 100).

New first defect: a publicly accepted FrozenMLPFunction with a CalibratedActivation
identity primitive having input_scale=2 and output_shift=1 evaluates input2 to5,
matching independent scalar arithmetic, but JSON reconstruction rejects that
same accepted record: "MLP activation parameters require at most one two-element
array". Decoder frozen_function_decoding.py:108-109 imposes a restriction absent
from the public record constructor. Component docs/issue-28-frozen-functions.md:
52-53 promise reconstruction of the same typed records from json/asdict output.

This finding does not request broadening the source prior. A coherent fix can
reject unsupported source activation options at construction, or reconstruct all
options the public constructor permits, with explicit documented scope.

Run `bash /tmp/r0-28-functions-spec-c58706e/reproduce.sh`.
Expected exit1. roundtrip.json retains exact fixture, scalar expected5/observed5,
decoder exception, environment, imported module paths/hashes, executed program hash.
The fixture's calibration identity/digest are authored placeholders: this is a
serialization contract check, not evidence of fitting or sampling provenance.

Commands executed with existing Python3.12.3, Torch2.15.0+cpu, CPU float64:
```
PYTHONPATH=/tmp/r0-28-functions-spec-c58706e/source/src /home/avist/Projects/r0/.venv/bin/python -B /tmp/r0-28-functions-spec-c58706e/check_ties.py > /tmp/r0-28-functions-spec-c58706e/check_ties.log 2>&1
PYTHONPATH=/tmp/r0-28-functions-spec-c58706e/source/src /home/avist/Projects/r0/.venv/bin/python -B /tmp/r0-28-functions-spec-c58706e/check_roundtrip.py > /tmp/r0-28-functions-spec-c58706e/roundtrip.log 2>&1
```
No harness failures. Stop-at-first-defect rule applied. Counts: 98 repaired tie
cases pass; one MLP arithmetic check passes; one roundtrip check fails. All broader
remaining numerical/composition/JSON/admission/immutability/legacy checks NOT_RUN.
The newly authored tree-mean repair has NOT_RUN independent executable verification.
No component acceptance, sampling/fitting/graph integration, GPU, browser, Colab,
resource measurement, or full issue28 claim. No scope creep identified.

## Exact narrow exports and reconstruction

Original commands from /tmp/r0-28 (use an empty artifact destination):
```
mkdir /tmp/r0-28-functions-spec-c58706e
mkdir /tmp/r0-28-functions-spec-c58706e/source /tmp/r0-28-functions-spec-c58706e/base
git archive c58706ec044568cc6b449a428c32d93c9b5ca7a1 src pyproject.toml AGENTS.md CODING_STANDARDS.md docs/requirements.md docs/specs/0028-causal-network-generators.md docs/research/0028-joint-root-function-plans.md docs/issue-28-frozen-functions.md | tar -x -C /tmp/r0-28-functions-spec-c58706e/source
git archive cb7977a916ff6f11d95790b2de4dd591ab8d3f39 src pyproject.toml AGENTS.md CODING_STANDARDS.md docs/requirements.md docs/specs/0028-causal-network-generators.md docs/research/0028-joint-root-function-plans.md | tar -x -C /tmp/r0-28-functions-spec-c58706e/base
cp /tmp/r0-28-functions-spec-690297b/check_ties.py /tmp/r0-28-functions-spec-c58706e/check_ties.py
cp /tmp/r0-28-functions-spec-690297b/I2func.py /tmp/r0-28-functions-spec-c58706e/I2func.py
git diff cb7977a916ff6f11d95790b2de4dd591ab8d3f39...c58706ec044568cc6b449a428c32d93c9b5ca7a1
```
Source cache SHA256 ff2939197b353f6d11a3fbaf0e27586998bdf93527dad11f24698ff296ce2f6c,
attributed TabICL9530bd65a7b806f6ad4f9f4335af745577e9d3cc, NOT freshly verified upstream.
Ruff logs use project config with known-first-party r0. Final executed bytes are
checked by manifest.py against receipts and the unchanged original tie program.
