#!/usr/bin/env bash
set -u
cd /tmp/r0-28-functions-spec-c58706e
export PYTHONPATH=/tmp/r0-28-functions-spec-c58706e/source/src
/home/avist/Projects/r0/.venv/bin/python -B check_roundtrip.py > roundtrip.log 2>&1
result=$?
printf '%s\n' "$result" > roundtrip.exit
cat roundtrip.log
exit "$result"
