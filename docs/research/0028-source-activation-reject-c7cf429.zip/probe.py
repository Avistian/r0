"""Portable independent Decimal oracle; no private implementation imports."""
import hashlib, json, os, subprocess, sys
from dataclasses import asdict
from decimal import Decimal, getcontext
from pathlib import Path
import numpy as np
import torch
from r0.modules import priors

getcontext().prec = 100
D = Decimal
EPS = D('0.0001')
out = Path(__file__).resolve().parent
sample = np.array([[1e16], [1e16 + 4]], dtype='<f8')
query = np.array([[1e16 + 8]], dtype='<f8')
(out/'sample.f64le').write_bytes(sample.tobytes())
(out/'query.f64le').write_bytes(query.tobytes())

def stats(xs):
    mean = sum(xs) / D(len(xs))
    std = (sum((x-mean)**2 for x in xs) / D(len(xs))).sqrt()
    return mean, 1/(std+EPS), std

def tanh(x):
    e = (2*x).exp()
    return (e-1)/(e+1)

xs = [D.from_float(float(v)) for v in sample[:,0]]
mu, inv, std = stats(xs)
rows = np.random.default_rng(0).integers(len(xs), size=1).tolist()
shift = -(xs[rows[0]]-mu)*inv
ys = [tanh((x-mu)*inv+shift) for x in xs]
mu2, inv2, std2 = stats(ys)
expected = float((tanh((D.from_float(float(query[0,0]))-mu)*inv+shift)-mu2)*inv2)
activation = priors.calibrate_source_activation(priors.CausalActivation('tanh'), sample,
    rng=np.random.default_rng(0), scale=1.0, calibration_id='independent-near-constant-1e16')
actual = float(activation.apply(torch.tensor(query)).item())
controls = priors.LinearRecipe(rows=16, context_rows=8, features=1, signal_features=1, active_features=1)
recipe = priors.CausalRecipe(task=controls, nodes=(
    priors.ActivatedCausalNode(bias=(float(query[0,0]),), noise_scale=(0.0,), output_activation=activation),
    priors.CausalNode()), observed=((1,0),), target=((0,0),), version='causal-v2')
raw_recipe = json.dumps(asdict(recipe), indent=2)
(out/'recipe.json').write_text(raw_recipe+'\n')
restored = priors.recipe_from_dict(json.loads(raw_recipe))
task = priors.generate_task(restored, seed=28, task_id=1)
trace = priors.explain_generation(task,[0,15])
(out/'trace.json').write_text(json.dumps(trace, indent=2)+'\n')
modules = {}
for name,module in sorted(sys.modules.items()):
    path = getattr(module,'__file__',None)
    if name.startswith('r0.') and path and path.endswith('.py'):
        modules[name] = {'path':path, 'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()}
(out/'imports.json').write_text(json.dumps(modules,indent=2)+'\n')
report = {
    'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/tmp/r0-28',text=True).strip(),
    'python':sys.executable,'numpy':np.__version__,'torch':torch.__version__,
    'threads':{k:os.environ.get(k) for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS')},
    'sample_hex':[float(v).hex() for v in sample[:,0]],
    'sample_sha256':hashlib.sha256(sample.tobytes()).hexdigest(),
    'query_hex':float(query[0,0]).hex(),
    'oracle':{'mean':str(mu),'std':str(std),'inverse_std':str(inv),'shift':str(shift),
              'output_mean':str(mu2),'output_inverse_std':str(inv2),'query_output':expected},
    'implementation':asdict(activation), 'actual_query_output':actual,
    'absolute_output_error':abs(actual-expected),
    'input_inverse_relative_error':abs(activation.input_inverse_std[0]/float(inv)-1),
    'restored_equal':restored==recipe,'generated_targets':task.targets.tolist(),
    'trace_target_max_error':trace['target_max_error'],
    'verdict':'REJECT' if abs(activation.input_inverse_std[0]/float(inv)-1)>1e-8 else 'PASS',
}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
assert report['verdict']=='REJECT', 'Expected numerical defect was not reproduced'
