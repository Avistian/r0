"""A JSON string path is silently converted into a different ownership hierarchy."""
import hashlib
import json
import platform
import sys
from dataclasses import asdict
from pathlib import Path

import numpy as np

from r0.modules import priors

out = Path(sys.argv[1])
out.mkdir(exist_ok=True)
context = priors.JointSamplingContext(np.random.default_rng(128))
with context.transaction('graph') as operation:
    operation.forced_identity('target', reason='target-warp-disabled')
record = context.freeze()
original = json.loads(json.dumps(asdict(record)))
(out / 'original.json').write_text(json.dumps(original, indent=2))
malformed = json.loads(json.dumps(original))
malformed['events'][0]['operation'] = 'graph'
(out / 'malformed-string-path.json').write_text(json.dumps(malformed, indent=2))
try:
    decoded = priors.joint_sampling_from_dict(malformed)
except (TypeError, ValueError) as exc:
    print(json.dumps({'verdict': 'REJECTED_AS_REQUIRED', 'error': str(exc)}))
else:
    (out / 'accepted-decoded.json').write_text(json.dumps(asdict(decoded), indent=2))
    print(json.dumps({'verdict': 'PRODUCT_DEFECT', 'supplied_path': malformed['events'][0]['operation'],
                      'actual_path': decoded.events[0].operation,
                      'original_owner': record.events[0].operation,
                      'owner_changed': decoded.events[0].operation != record.events[0].operation}))
imports = {}
for name, module in sorted(sys.modules.items()):
    filename = getattr(module, '__file__', None)
    if name.startswith('r0.') and filename and Path(filename).is_file():
        imports[name] = {'path': filename, 'sha256': hashlib.sha256(Path(filename).read_bytes()).hexdigest()}
(out / 'imports.json').write_text(json.dumps(imports, indent=2))
(out / 'environment.json').write_text(json.dumps({'python': sys.version, 'executable': sys.executable,
    'numpy': np.__version__, 'platform': platform.platform(), 'priors_file': priors.__file__,
    'source': '2812d23b390a44f5b817c4a2a112de369861ee56'}, indent=2))
