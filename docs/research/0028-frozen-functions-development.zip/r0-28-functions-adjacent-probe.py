import math
import torch
from r0.modules import priors
for p in (0.5,0.75,1.0,1.5,2.0,3.0,4.0):
    for near in (0.5,1.0,1e10,1e100):
        far=math.nextafter(near,math.inf)
        f=priors.FrozenDiscretizationFunction(((far,),(near,)),priors.FrozenLinearFunction(((1.0,),)),p)
        observed=priors.evaluate_frozen_function(f,torch.zeros((1,1),dtype=torch.float64)).item()
        print(p,near,observed,observed==near,flush=True)
